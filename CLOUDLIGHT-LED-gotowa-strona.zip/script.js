document.getElementById("year").textContent = new Date().getFullYear();

document.getElementById("quoteForm").addEventListener("submit", function(e){
  e.preventDefault();
  const data = new FormData(this);
  const subject = "Zapytanie o wycenę — CLOUDLIGHT LED";
  const body =
`Dzień dobry,

chciałbym/chciałabym zapytać o wycenę chmury LED.

Imię / firma: ${data.get("name")}
Telefon: ${data.get("phone")}
Rodzaj realizacji: ${data.get("type")}
Orientacyjny metraż: ${data.get("size")}

Opis:
${data.get("message")}

Pozdrawiam`;
  window.location.href = "mailto:kontakt@cloudlight-led.pl?subject=" +
    encodeURIComponent(subject) + "&body=" + encodeURIComponent(body);
});
